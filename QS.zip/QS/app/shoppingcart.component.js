"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent() {
        this.productToBeSearched = "";
        this.newProduct = {};
        this.products = [
            { name: 'Laptop', price: 50000, quantity: 100, rating: 4, launchdate: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home" },
            { name: 'LED TV', price: 25000, quantity: 10, rating: 3.2780, launchdate: new Date(), description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home" },
            { name: 'Desktop', price: 10000, quantity: 200, rating: 3, launchdate: new Date(), description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home" },
            { name: 'Mobile', price: 20000, quantity: 1000, rating: 5, launchdate: new Date(), description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home" },
            { name: 'Camera', price: 90000, quantity: 10, rating: 4, launchdate: new Date(), description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home" }
        ];
    }
    ShoppingCartComponent.prototype.onFormSubmit = function (formPassed, e) {
        console.log(formPassed.valid);
        e.preventDefault(); // suppress submitting of the form !
        var newProductToBeAdded = {
            name: this.newProduct.name,
            price: this.newProduct.price,
            quantity: this.newProduct.quantity,
            rating: this.newProduct.rating,
        };
        this.products.push(newProductToBeAdded);
    };
    ShoppingCartComponent = __decorate([
        core_1.Component({
            selector: 'shoppingcart',
            templateUrl: '/app/shoppingcart.component.html'
        }), 
        __metadata('design:paramtypes', [])
    ], ShoppingCartComponent);
    return ShoppingCartComponent;
}());
exports.ShoppingCartComponent = ShoppingCartComponent;
//# sourceMappingURL=shoppingcart.component.js.map