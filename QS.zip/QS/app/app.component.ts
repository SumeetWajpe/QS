import { Component } from '@angular/core';
@Component({
  selector: 'my-app',
  template:`<shoppingcart></shoppingcart>  
  `
})
export class AppComponent  { 
  
 }
