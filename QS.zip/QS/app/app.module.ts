import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { AppComponent }  from './app.component';
import {ShoppingCartComponent} from './shoppingcart.component';
import {ProductComponent} from './product.component';
import {SummaryPipe} from './summary.pipe';

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent,
                          ProductComponent,
                          ShoppingCartComponent,
                          SummaryPipe
                           ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
